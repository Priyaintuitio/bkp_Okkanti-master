$(document).ready(function () {
  const loginFormValidator = $("#login_form").validate({
    rules: {
      email: {
        required: true,
        email: true,
      },
      pwd: {
        required: true,
      },
    },
    messages: {
      email: {
        required: "Please enter your email",
        email: "Please enter a valid email",
      },
      pwd: {
        required: "Please enter your password",
      },
    },
  });
  const forgotPwdFormValidator = $("#forgot_pwd_form").validate({
    rules: {
      email: {
        required: true,
        email: true,
      },
    },
    messages: {
      email: {
        required: "Please enter your email",
        email: "Please enter a valid email",
      },
    },
  });
  $(".selectivo").selectivo();
  // Toggle menu
  $("#ham_menu_toggle").click(() => {
    toggleHamburgerMenu();
  });

  var testimonial_slider = $(".okn_testimonial-container").slick({
    dots: false,
    arrows: false,
    infinite: true,
    fade: true,
    cssEase: "linear",
  });

  $(".okn_slick-left").on("click", () => {
    testimonial_slider.slick("slickPrev");
  });
  $(".okn_slick-right").on("click", () => {
    testimonial_slider.slick("slickNext");
  });

  // Closing navigation menu on link click
  $(".okn_header-main-menu ul li a").click(() => {
    toggleHamburgerMenu();
  });
  // Closing on Outside click
  $(document).on("click", function (e) {
    if ($(e.target).hasClass("po_menu-container")) {
      toggleHamburgerMenu();
    }
  });
  // FAQ
  $(".okn_ques").on("click", function () {
    $(".okn_ques").not(this).removeClass("active");
    $(".okn_ques").not(this).siblings(".okn_ans").slideUp();
    $(this).siblings(".okn_ans").slideToggle(300);
    $(this).toggleClass("active");
  });

  // Password Toggle
  $("#toggle_pwd").on("click", function () {
    let pwd = $("#pwd").attr("type");
    if (pwd === "password") {
      $("#pwd").attr("type", "text");
      $("#open-eye").addClass("hide");
      $("#close-eye").removeClass("hide");
    } else {
      $("#pwd").attr("type", "password");
      $("#open-eye").removeClass("hide");
      $("#close-eye").addClass("hide");
    }
  });

  // Open modal
  $(".login-btn").on("click", function () {
    $(".login-modal-wrapper").removeClass("hide");
    $(".forgot-pwd-wrapper").addClass("hide");
    $("#forgot_pwd_form").trigger("reset");
    forgotPwdFormValidator.resetForm();
    $("#login_form").trigger("reset");
    loginFormValidator.resetForm();
    toggleLoginModal();
  });

  // Close modal
  $(".modal-close-icon").on("click", function () {
    toggleLoginModal();
  });

  // Close modal on outside click
  $(document).on("click", function (e) {
    if ($(e.target).hasClass("okn_modal-container")) {
      toggleLoginModal();
    }
  });

  // Forgot password
  $(".login-forgot-pwd").on("click", function () {
    $(".login-modal-wrapper").addClass("hide");
    $(".forgot-pwd-wrapper").removeClass("hide");
    $("#forgot_pwd_form").trigger("reset");
    forgotPwdFormValidator.resetForm();
  });

  //Remember password
  $(".remember-pwd").on("click", function () {
    $(".login-modal-wrapper").removeClass("hide");
    $(".forgot-pwd-wrapper").addClass("hide");
    $("#login_form").trigger("reset");
    loginFormValidator.resetForm();
  });
});

function toggleHamburgerMenu() {
  $(".okn_header").toggleClass("opened");
  $("body").toggleClass("menu-opened");
}

function toggleLoginModal() {
  $(".okn_modal-container").toggleClass("show");
  $("body").toggleClass("modal-active");
}
