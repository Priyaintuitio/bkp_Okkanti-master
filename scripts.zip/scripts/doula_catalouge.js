jQuery(function(jQuery){
	jQuery('#filter').submit(function(){
		var filter = jQuery('#filter');
		var categoryfilter = jQuery('#categoryfilter').val();
		var visit_typefilter = jQuery('#visit_typefilter').val();
		var distance = jQuery('#distance').val();
		var zipcode = jQuery('#zipcode').val();
		/* console.log("distanceTEST : ");
		console.log("distance : "+distance);
		console.log("zipcode : "+zipcode); */
		
		//console.log("categoryfilter : "+categoryfilter);
		//console.log("visit_typefilter : "+visit_typefilter);
		var dataVal = 
		jQuery.ajax({
			url:filter.attr('action'),
			//data:filter.serialize(), // form data
			data: 'categoryfilter='+categoryfilter+'&visit_typefilter='+visit_typefilter,
			data:filter.serialize(), // form data
			type:filter.attr('method'), // POST
			beforeSend:function(xhr){
				filter.find('button').text('Processing...'); // changing the button label
			},
			success:function(data){
				jQuery("#filterPagination").html('');
				jQuery('#pagination_result').hide();
				jQuery('#paginationFilterResult').show();
				filter.find('button').text('Search'); // changing the button label back
				//jQuery('#ajax_filter_doula').html(data); // insert data

				//spilt data here
				var arrContent = data.split('@$@');
				var htmlLoopData = arrContent[0];
				var paginationData = arrContent[1];
				
				// blog data set here
				jQuery('#ajax_filter_doula').html(htmlLoopData); 


				console.log("extra data : "+paginationData);

				var arrPaged = paginationData.split('@#@');
				jQuery('#hiddenMaxNumPages').val(arrPaged[0]);
				 
				var arrTotalPost = arrPaged[1].split('@%@');
				jQuery('#hiddenTotalPost').val(arrTotalPost[0]);
				
				console.log("pagination data : "+arrTotalPost[1]);
				//jQuery('#ajax_filter_doula').val(htmlLoopData); 

				//jQuery('#pagination_result').html(paginationData); 

				jQuery('#visit_typefilter').val(visit_typefilter);
				jQuery('#hiddenvisit_typefilter').val(visit_typefilter);
				 //jQuery("#response").html(htmlData.filter("#ajax_filter_doula").outerHTML);


				var total_pages = Math.ceil(arrTotalPost[0]/2);
				console.log("total_pages :: "+total_pages); 

				var options = new Array();
				var filterPaginationData = '';
				for (i = 1; i <= total_pages; i++) {
				    //.html("<span>" + i + "<span>");
				    options.push('<span>'+ i +'</span>');
				}
				jQuery("#filterPagination").append(options.join(''));
				//jQuery("#filterPagination").append(filterPaginationData);

			}
		});
		return false;
	});
});

